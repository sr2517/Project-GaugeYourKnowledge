package com.cognizant.service;

import com.cognizant.model.Exam;


public interface ExamService {
	public boolean insertExam(Exam exam);
}
